<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>SMP NEGERI 2 GREGED</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="#" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="style.css" rel="stylesheet">
</head>

<body>

    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="index.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 class="m-0 text-primary"><i class="#"></i>SMP NEGERI 2 GREGED</h2>
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="index.html" class="nav-item nav-link active">Home</a>
                <a href="about.html" class="nav-item nav-link">About</a>
                <a href="courses.html" class="nav-item nav-link">Courses</a>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="team.html" class="dropdown-item">Our Team</a>
                        <a href="testimonial.html" class="dropdown-item">Testimonial</a>
                        <a href="404.html" class="dropdown-item">404 Page</a>
                    </div>
                </div>
                <a href="contact.html" class="nav-item nav-link">Contact</a>
            </div>
            <a href="" class="btn btn-primary py-4 px-lg-5 d-none d-lg-block">Join Now<i class="fa fa-arrow-right ms-3"></i></a>
        </div>
    </nav>
    <!-- Navbar End -->

  <header class="page-header text-white" style="background-image:url('img/logo.jpg')">
    <div class="container text-center py-5">
      <h1 class="display-4">Syarat & Tata Cara Pendaftaran</h1>
    </div>
  </header>

  <main class="container py-5">
    <h3>Syarat Umum</h3>
    <ol>
      <li>Fotokopi Ijazah (dilegalisasi, asli ditunjukan)</li>
      <li>Lembar Validasi NISN</li>
      <li>Fotokopi Kartu Keluarga</li>
      <li>Fotokopi Akta Kelahiran/surat keterangan lahir (dilegalisasi);</li>
      <li>Fotokopi KTP Orang tua/wali;</li>
      <li>Surat Kelakuan Baik</li>
      <li>Suket Lulus MD (asli) jika ada</li>
<li>creenshoot titik koordinat (latitude atau garis
lintang dan longitude atau garis bujur) domisi/tempat tinggal CMB
</li>
      <li>Surat Pertanggungjawaban mutlak dari orang tua (asli)
</li>
<li>Pas Foto Ukuran 4x6 (2 Lembar)</li>
 </ol>

    <h3 class="mt-4">Persyaratan Tambahan</h3>
    <ol>
      <li> Fotokopi KIP</li>
      <li>Surat Keterangan Terdaftar DTSEN (Data Sosial Ekonomi Nasional)</li>
      <li>Surat Keterangan dari Dokter/Puskesmas/Rumah Sakit</li>
      <li>Fotokopi rapor 5 (lima) semester terakhir</li>
<li>Suket kepala sekolah jalur prestasi akademik nilai rapor</li>
      <li>Fotokopi sertifikat kejuaraan/sertifkat prestasi akademik atau non akademik</li>
      <li>Fotokopi Surat penugasan dari instasi, Lembaga, atau kantor yang memperkerjakan</li>
      <li>Fotokopi Surat keterangan domisili</li>
      <li>Fotokopi SK Penugasan sebagai guru/tenaga kependidikan</li>
      <li>Kartu Keluarga minimal 1 tahun</li>
 </ol>
 </main>

  <footer class="footer py-3">
    <div class="container d-flex justify-content-between small">
      <div>SMPN 2 GREGED &copy; 2025</div>
      
    </div>

  </footer>

  <a href="#" class=""><i class="fa fa-arrow-up"></i></a>
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="js/main.js"></script>
</body>
</html>