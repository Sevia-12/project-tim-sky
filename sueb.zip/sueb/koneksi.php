<?php 
$server="localhost";
$user="root";
$password="";
$nama_database="Darto";

$koneksi=mysqli_connect ("localhost","root","","Darto");

if( !$koneksi ){
   
   die("Gagal terhubung dengan database:".mysqli_connect_error());
}

 ?>